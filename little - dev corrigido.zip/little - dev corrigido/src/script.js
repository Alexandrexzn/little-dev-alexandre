// ==================== VARIÁVEIS GLOBAIS ====================
let dataSelecionada = null;
let salaSelecionada = null;
let mesAtual = new Date().getMonth();
let anoAtual = new Date().getFullYear();

// ==================== CARREGAR DO BANCO — VERSÃO FINAL E INDESTRUTÍVEL ====================
async function carregarDoBanco() {
  try {
    const res = await fetch('/api/dados');
    if (!res.ok) throw new Error(`Erro ${res.status}`);

    const { salas, reservas } = await res.json();

    document.querySelectorAll('#reservadas .sala-linha, #disponiveis .sala-linha')
      .forEach(linha => linha.innerHTML = '');

    salas.forEach(sala => {
      const reserva = reservas.find(r => r.id_sala === sala.id_sala);

      const card = document.createElement('div');
      card.className = `sala-card ${reserva ? '' : 'disponivel'}`;
      card.dataset.sala = sala.nome_sala;

      card.innerHTML = `
        <div class="sala-header">
          <img src="./icons/${reserva ? 'education' : 'computer'}.png" class="sala-icone-img">
          <div class="sala-info">
            <p>${reserva ? reserva.professor : 'Disponível'}</p>
            <h3>${sala.nome_sala}</h3>
            <div class="acoes-sala">
              <button class="btn-editar" title="Editar"><i class="fas fa-edit"></i></button>
              <button class="btn-excluir" title="Excluir"><i class="fas fa-trash-alt"></i></button>
            </div>
          </div>
        </div>
        <div class="sala-detalhes">
          ${reserva 
            ? `<span class="periodo">${new Date(reserva.data_reserva).toLocaleDateString('pt-BR')} • ${reserva.horario_inicio} - ${reserva.horario_fim}</span>
               <span class="capacidade">capacidade ${sala.capacidade || '30'}</span>`
            : '<button class="btn-reservar">RESERVAR</button>'
          }
        </div>
      `;

      if (reserva) {
        document.querySelectorAll('#reservadas .sala-linha')
          .forEach(linha => linha.appendChild(card.cloneNode(true)));
      } else {
        const linhaDisp = document.querySelector('#disponiveis .sala-linha');
        if (linhaDisp) linhaDisp.appendChild(card);
      }
    });

  } catch (err) {
    console.error('Erro:', err);
    const erroHTML = `
      <div style="text-align:center; padding:40px; background:#ffebee; border:3px solid #f44336; border-radius:16px; margin:30px; color:#c62828;">
        <h3>Servidor não está rodando</h3>
        <p>Abra o terminal e execute:</p>
        <code style="background:#000; color:#4caf50; padding:15px 25px; border-radius:10px; font-size:20px;">node server.js</code>
      </div>
    `;
    document.querySelectorAll('#reservadas .sala-linha, #disponiveis .sala-linha')
      .forEach(linha => linha.innerHTML = erroHTML);
  }
}

// ==================== CALENDÁRIO 100% FUNCIONAL E LINDO ====================
function gerarCalendario(mes, ano) {
  const grid = document.getElementById('calendario-grid');
  const titulo = document.getElementById('mes-ano');
  if (!grid || !titulo) return;

  grid.innerHTML = '';
  titulo.textContent = `${['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'][mes]} ${ano}`;

  const primeiroDia = new Date(ano, mes, 1).getDay();
  const diasNoMes = new Date(ano, mes + 1, 0).getDate();
  const hoje = new Date();

  for (let i = 0; i < primeiroDia; i++) {
    grid.appendChild(document.createElement('div'));
  }

  for (let dia = 1; dia <= diasNoMes; dia++) {
    const celula = document.createElement('div');
    celula.classList.add('dia');
    celula.textContent = dia;

    if (dia === hoje.getDate() && mes === hoje.getMonth() && ano === hoje.getFullYear()) {
      celula.classList.add('hoje');
    }

    celula.addEventListener('click', () => {
      document.querySelectorAll('.dia').forEach(d => d.classList.remove('selecionado'));
      celula.classList.add('selecionado');
      dataSelecionada = new Date(ano, mes, dia);
    });

    grid.appendChild(celula);
  }
}

// Navegação do calendário
document.getElementById('mes-anterior')?.addEventListener('click', () => {
  if (--mesAtual < 0) { mesAtual = 11; anoAtual--; }
  gerarCalendario(mesAtual, anoAtual);
});

document.getElementById('mes-proximo')?.addEventListener('click', () => {
  if (++mesAtual > 11) { mesAtual = 0; anoAtual++; }
  gerarCalendario(mesAtual, anoAtual);
});

// Confirmar data
document.getElementById('confirmar-data')?.addEventListener('click', () => {
  if (!dataSelecionada) return alert('Selecione uma data!');
  const dataStr = dataSelecionada.toLocaleDateString('pt-BR');
  document.getElementById('sala-reserva-titulo').textContent = `${salaSelecionada} • ${dataStr}`;
  document.getElementById('modalCalendario').style.display = 'none';
  document.getElementById('modalReserva').style.display = 'flex';
});

// ==================== EVENTOS PRINCIPAIS ====================
function mostrarTela(id) {
  document.querySelectorAll('.tela').forEach(t => t.classList.remove('ativa'));
  document.getElementById(id)?.classList.add('ativa');
  document.querySelectorAll('.sidebar li').forEach(li => li.classList.remove('active'));
  document.querySelector(`.sidebar li[onclick="mostrarTela('${id}')"]`)?.classList.add('active');
  if (id === 'reservadas' || id === 'disponiveis') carregarDoBanco();
}

// Reservar sala
document.addEventListener('click', e => {
  if (e.target.closest('.btn-reservar')) {
    salaSelecionada = e.target.closest('.sala-card').dataset.sala;
    document.getElementById('modalCalendario').style.display = 'flex';
    gerarCalendario(mesAtual, anoAtual);
  }
});

// Confirmar reserva final
document.getElementById('confirmar-reserva-final')?.addEventListener('click', async () => {
    const professor = document.getElementById('nome-professor')?.value.trim();
    const inicio = document.getElementById('hora-inicio-reserva')?.value;
    const fim = document.getElementById('hora-fim-reserva')?.value;
  
    if (!professor || !inicio || !fim || !dataSelecionada || !salaSelecionada) {
      return alert('Preencha todos os campos!');
    }
  
    if (inicio >= fim) {
      return alert('A hora de início deve ser antes da hora de fim!');
    }
  
    const dataISO = dataSelecionada.toISOString().split('T')[0];
  
    try {
      const response = await fetch('/api/reserva', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nome_sala: salaSelecionada,
          professor: professor,
          data_reserva: dataISO,
          horario_inicio: inicio,
          horario_fim: fim
        })
      });
  
      const resultado = await response.json();
  
      if (response.ok && resultado.success) {
        alert('Reserva confirmada com sucesso!');
        document.getElementById('modalReserva').style.display = 'none';
        
        // Limpa os campos
        document.getElementById('nome-professor').value = '';
        document.getElementById('hora-inicio-reserva').value = '';
        document.getElementById('hora-fim-reserva').value = '';
        
        carregarDoBanco(); // Atualiza as salas
      } else {
        alert(resultado.message || 'Este horário já está reservado!');
      }
    } catch (err) {
      console.error('Erro ao reservar:', err);
      alert('Erro de conexão. Verifique se o servidor está rodando.');
    }
  });

// Excluir reserva
document.addEventListener('click', async e => {
  const btn = e.target.closest('.btn-excluir');
  if (!btn || !confirm('Cancelar esta reserva?')) return;

  const card = btn.closest('.sala-card');
  const periodo = card.querySelector('.periodo')?.textContent;
  if (!periodo) return;

  const [dataStr, horario] = periodo.split(' • ');
  const [dia, mes, ano] = dataStr.split('/');
  const dataReserva = `${ano}-${mes.padStart(2,'0')}-${dia.padStart(2,'0')}`;
  const horario_inicio = horario.split(' - ')[0];

  await fetch('/api/reserva', {
    method: 'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nome_sala: card.querySelector('h3').textContent, data_reserva: dataReserva, horario_inicio })
  });

  carregarDoBanco();
});

// Fechar modais
document.querySelectorAll('.fechar-modal, .fechar-reserva, .cancelar-reserva').forEach(el => {
  el.addEventListener('click', () => {
    document.getElementById('modalCalendario').style.display = 'none';
    document.getElementById('modalReserva').style.display = 'none';
  });
});

document.getElementById('modalCalendario')?.addEventListener('click', e => {
  if (e.target === e.currentTarget) e.currentTarget.style.display = 'none';
});

// Modo escuro
document.getElementById('darkMode')?.addEventListener('change', e => {
  document.body.classList.toggle('dark-mode', e.target.checked);
  localStorage.setItem('modoEscuro', e.target.checked);
});

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
  const dark = localStorage.getItem('modoEscuro') === 'true';
  if (document.getElementById('darkMode')) {
    document.getElementById('darkMode').checked = dark;
    if (dark) document.body.classList.add('dark-mode');
  }
  mostrarTela('reservadas');
  gerarCalendario(mesAtual, anoAtual);
  carregarDoBanco();
});