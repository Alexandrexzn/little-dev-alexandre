// server.js  ←←← SALVE COM ESSE NOME EXATO
const express = require('express');
const mysql = require('mysql2/promise');
const app = express();
const PORT = 8080;

app.use(express.json());
app.use(express.static('src')); // ← sua pasta com index.html, script.js, style.css

// Conexão com MySQL
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '123456',  // ← mude se a sua senha for diferente
  database: 'projeto_salas'
});

db.getConnection()
  .then(() => console.log('MySQL conectado!'))
  .catch(err => console.error('Erro MySQL:', err));

// ===================== ROTAS =====================

// Página inicial
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/src/index.html');
});

// Todas as salas + reservas do dia atual
app.get('/api/dados', async (req, res) => {
  try {
    const [salas] = await db.query('SELECT * FROM salas');
    const [reservas] = await db.query(`
      SELECT r.*, s.nome_sala 
      FROM reservas r 
      JOIN salas s ON r.id_sala = s.id_sala 
      WHERE r.data_reserva = CURDATE()
    `);
    res.json({ salas, reservas });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro no servidor' });
  }
});

// RESERVA ← AQUI ESTAVA O PROBLEMA!
app.post('/api/reserva', async (req, res) => {
  const { nome_sala, professor, data_reserva, horario_inicio, horario_fim } = req.body;

  try {
    // 1. Busca o id da sala
    const [sala] = await db.query('SELECT id_sala FROM salas WHERE nome_sala = ?', [nome_sala]);
    if (sala.length === 0) return res.json({ success: false, message: 'Sala não encontrada' });

    const id_sala = sala[0].id_sala;

    // 2. Verifica conflito
    const [conflito] = await db.query(`
      SELECT * FROM reservas 
      WHERE id_sala = ? AND data_reserva = ?
      AND (horario_inicio < ? AND horario_fim > ?)
      OR (horario_inicio < ? AND horario_fim > ?)
      OR (horario_inicio >= ? AND horario_fim <= ?)
    `, [id_sala, data_reserva, horario_fim, horario_inicio, horario_fim, horario_inicio, horario_inicio, horario_fim]);

    if (conflito.length > 0) {
      return res.json({ success: false, message: 'Horário já reservado!' });
    }

    // 3. Insere a reserva
    await db.query(
      'INSERT INTO reservas (id_sala, professor, data_reserva, horario_inicio, horario_fim) VALUES (?, ?, ?, ?, ?)',
      [id_sala, professor, data_reserva, horario_inicio, horario_fim]
    );

    res.json({ success: true });
  } catch (err) {
    console.error('Erro ao reservar:', err);
    res.status(500).json({ success: false, message: 'Erro interno' });
  }
});

// Cancelar reserva
app.delete('/api/reserva', async (req, res) => {
  const { nome_sala, data_reserva, horario_inicio } = req.body;
  try {
    const [sala] = await db.query('SELECT id_sala FROM salas WHERE nome_sala = ?', [nome_sala]);
    if (sala.length === 0) return res.json({ success: false });

    await db.query('DELETE FROM reservas WHERE id_sala = ? AND data_reserva = ? AND horario_inicio = ?', 
      [sala[0].id_sala, data_reserva, horario_inicio]);

    res.json({ success: true });
  } catch (err) {
    res.json({ success: false });
  }
});

app.listen(PORT, () => {
  console.log(`\nSERVIDOR RODANDO → http://localhost:${PORT}`);
  console.log('Teste agora que vai funcionar 100%!\n');
});