// db.js
const mysql = require('mysql2/promise'); // <-- VERSÃO PROMISE!

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '123456', // mude se sua senha for diferente
  database: 'projeto_salas',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

console.log('Conectado ao MySQL com sucesso!');

module.exports = pool;