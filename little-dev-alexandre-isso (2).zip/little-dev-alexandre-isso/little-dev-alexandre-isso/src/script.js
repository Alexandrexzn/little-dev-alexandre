// TROCA ENTRE TELAS
function mostrarTela(id) {
    document.querySelectorAll('.tela').forEach(tela => tela.classList.remove('ativa'));
    document.getElementById(id).classList.add('ativa');
    document.querySelectorAll('.sidebar li').forEach(item => item.classList.remove('active'));
    const menuItem = document.querySelector(`.sidebar li[onclick="mostrarTela('${id}')"]`);
    if (menuItem) menuItem.classList.add('active');
}

// MODO ESCURO
document.getElementById('darkMode').addEventListener('change', function () {
    document.body.classList.toggle('dark-mode', this.checked);
    localStorage.setItem('modoEscuro', this.checked);
});
document.addEventListener('DOMContentLoaded', () => {
    const modoEscuro = localStorage.getItem('modoEscuro') === 'true';
    document.getElementById('darkMode').checked = modoEscuro;
    if (modoEscuro) document.body.classList.add('dark-mode');
});

// CADASTRO
document.getElementById('formCadastro').addEventListener('submit', function (e) {
    e.preventDefault();
    const nome = document.getElementById('nomeSala').value.trim();
    const tipo = document.getElementById('tipoSala').value.trim();
    const andar = document.getElementById('andarSala').value;
    const erroDiv = document.getElementById('erroCadastro');

    const nomeValido = /^\d{2,10}$/.test(nome);
    const tipoValido = /^[\wÀ-ÿ\s-]{3,}$/.test(tipo) && /[A-Za-zÀ-ÿ]/.test(tipo);
    const salaExiste = Array.from(document.querySelectorAll('.sala-card')).some(card => card.dataset.sala === nome);

    if (!nomeValido || !tipoValido || !andar || salaExiste) {
        erroDiv.style.display = 'block';
        erroDiv.textContent = salaExiste ? 'Esta sala já está cadastrada.' : 'Preencha corretamente.';
        return;
    }

    const novoCard = document.createElement('div');
    novoCard.className = 'sala-card disponivel';
    novoCard.dataset.sala = nome;
    novoCard.innerHTML = `
        <div class="sala-header">
            <i class="fas fa-desktop"></i>
            <div class="sala-info">
                <p>Livre</p>
                <h3>${nome}</h3>
                <div class="acoes-sala">
                    <button class="btn-editar" title="Editar sala"><i class="fas fa-edit"></i></button>
                    <button class="btn-excluir" title="Excluir sala"><i class="fas fa-trash-alt"></i></button>
                </div>
            </div>
        </div>
        <div class="sala-detalhes">
            <span class="periodo">Período</span>
            <button class="btn-calendario">Calendário</button>
            <span-alterar>capacidade 30</span>
        </div>
    `;
    document.querySelector('#disponiveis .sala-linha').appendChild(novoCard);
    this.reset();
    document.getElementById('andarSala').selectedIndex = 0;
    erroDiv.style.display = 'none';
    alert(`Sala ${nome} cadastrada!`);
});

// CALENDÁRIO E RESERVA
let dataSelecionada = null, salaSelecionada = null, cardSelecionado = null;
const modal = document.getElementById('modalCalendario');
const fecharModal = document.querySelector('.fechar-modal');
const mesAno = document.getElementById('mes-ano');
const grid = document.getElementById('calendario-grid');
const anterior = document.getElementById('mes-anterior');
const proximo = document.getElementById('mes-proximo');
const confirmarBtn = document.getElementById('confirmar-data');
let dataAtual = new Date();

function renderizarCalendario() {
    grid.innerHTML = '';
    const ano = dataAtual.getFullYear(), mes = dataAtual.getMonth();
    mesAno.textContent = dataAtual.toLocaleString('pt-BR', { month: 'long', year: 'numeric' }).replace(/^\w/, c => c.toUpperCase());
    const primeiroDia = new Date(ano, mes, 1).getDay();
    const ultimoDia = new Date(ano, mes + 1, 0).getDate();
    const hoje = new Date(); hoje.setHours(0,0,0,0);

    for (let i = 0; i < primeiroDia; i++) grid.appendChild(document.createElement('div'));
    for (let dia = 1; dia <= ultimoDia; dia++) {
        const dataDia = new Date(ano, mes, dia);
        const celula = document.createElement('div');
        celula.classList.add('dia-calendario');
        celula.textContent = dia;
        if (dataDia < hoje) celula.classList.add('indisponivel');
        else celula.addEventListener('click', () => {
            document.querySelectorAll('.dia-calendario').forEach(d => d.classList.remove('selecionado'));
            celula.classList.add('selecionado');
            dataSelecionada = dataDia;
        });
        if (dataDia.toDateString() === hoje.toDateString()) celula.classList.add('hoje');
        grid.appendChild(celula);
    }
}

anterior.addEventListener('click', () => { dataAtual.setMonth(dataAtual.getMonth() - 1); renderizarCalendario(); });
proximo.addEventListener('click', () => { dataAtual.setMonth(dataAtual.getMonth() + 1); renderizarCalendario(); });

document.addEventListener('click', e => {
    if (e.target.classList.contains('btn-calendario')) {
        cardSelecionado = e.target.closest('.sala-card');
        salaSelecionada = cardSelecionado.querySelector('h3').textContent;
        modal.style.display = 'flex';
        dataSelecionada = null;
        document.querySelectorAll('.dia-calendario').forEach(d => d.classList.remove('selecionado'));
        renderizarCalendario();
    }
});

fecharModal.addEventListener('click', () => modal.style.display = 'none');
window.addEventListener('click', e => { if (e.target === modal) modal.style.display = 'none'; });

confirmarBtn.addEventListener('click', () => {
    if (!dataSelecionada) return alert('Selecione uma data.');
    const nomeUsuario = prompt("Seu nome:", "");
    if (!nomeUsuario?.trim()) return alert("Nome obrigatório.");

    if (cardSelecionado?.classList.contains('disponivel')) cardSelecionado.remove();

    const novaSala = document.createElement('div');
    novaSala.className = 'sala-card';
    novaSala.dataset.sala = salaSelecionada;
    novaSala.innerHTML = `
        <div class="sala-header">
            <i class="fas fa-desktop"></i>
            <div class="sala-info">
                <p>${nomeUsuario}</p>
                <h3>${salaSelecionada}</h3>
                <div class="acoes-sala">
                    <button class="btn-editar"><i class="fas fa-edit"></i></button>
                    <button class="btn-excluir"><i class="fas fa-trash-alt"></i></button>
                </div>
            </div>
        </div>
        <div class="sala-detalhes">
            <span class="periodo">${dataSelecionada.toLocaleDateString('pt-BR')}</span>
            <button class="btn-calendario">Calendário</button>
            <span class="capacidade">capacidade 30</span>
        </div>
    `;
    document.querySelector('#reservadas .sala-linha').appendChild(novaSala);
    modal.style.display = 'none';
    alert(`Reserva confirmada para ${nomeUsuario}!`);
});

// PERÍODO
let cardPeriodo = null;
const modalPeriodo = document.getElementById('modalPeriodo');
document.addEventListener('click', e => {
    if (e.target.classList.contains('periodo')) {
        cardPeriodo = e.target.closest('.sala-card');
        modalPeriodo.style.display = 'flex';
    }
});
document.querySelector('.fechar-periodo').addEventListener('click', () => modalPeriodo.style.display = 'none');
window.addEventListener('click', e => { if (e.target === modalPeriodo) modalPeriodo.style.display = 'none'; });
document.getElementById('confirmar-periodo').addEventListener('click', () => {
    const periodo = document.querySelector('input[name="periodo"]:checked')?.value;
    const inicio = document.getElementById('hora-inicio').value;
    const fim = document.getElementById('hora-fim').value;
    if (!periodo || !inicio || !fim) return alert('Preencha tudo.');
    cardPeriodo.querySelector('.periodo').textContent = `${periodo} ${inicio} - ${fim}`;
    modalPeriodo.style.display = 'none';
});

// EDIÇÃO E EXCLUSÃO
let salaEditando = null;
const modalEdicao = document.getElementById('modalEdicao');
document.addEventListener('click', e => {
    if (e.target.closest('.btn-editar')) {
        salaEditando = e.target.closest('.sala-card');
        const nome = salaEditando.querySelector('h3').textContent;
        const responsavel = salaEditando.querySelector('p').textContent;
        const capacidade = salaEditando.querySelector('.capacidade').textContent.replace('capacidade ', '');
        document.getElementById('editar-nome').value = nome;
        document.getElementById('editar-responsavel').value = responsavel;
        document.getElementById('editar-capacidade').value = capacidade;
        modalEdicao.style.display = 'flex';
    }
    if (e.target.closest('.btn-excluir')) {
        const card = e.target.closest('.sala-card');
        if (confirm(`Excluir sala ${card.querySelector('h3').textContent}?`)) card.remove();
    }
});
document.querySelector('.fechar-edicao').addEventListener('click', () => modalEdicao.style.display = 'none');
window.addEventListener('click', e => { if (e.target === modalEdicao) modalEdicao.style.display = 'none'; });
document.querySelector('.btn-salvar-edicao').addEventListener('click', () => {
    const novoNome = document.getElementById('editar-nome').value.trim();
    const novoResp = document.getElementById('editar-responsavel').value.trim();
    const novaCap = document.getElementById('editar-capacidade').value;
    if (!novoNome || !novoResp || !novaCap || !/^\d{2,10}$/.test(novoNome)) return alert('Dados inválidos.');
    if (Array.from(document.querySelectorAll('.sala-card')).some(c => c.dataset.sala === novoNome && c !== salaEditando)) return alert('Sala já existe.');
    salaEditando.dataset.sala = novoNome;
    salaEditando.querySelector('p').textContent = novoResp;
    salaEditando.querySelector('h3').textContent = novoNome;
    salaEditando.querySelector('.capacidade').textContent = `capacidade ${novaCap}`;
    modalEdicao.style.display = 'none';
});

// INICIAR
document.addEventListener('DOMContentLoaded', () => {
    mostrarTela('reservadas');
    renderizarCalendario();
});