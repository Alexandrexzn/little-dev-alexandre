// Troca entre telas do menu lateral
function mostrarTela(id) {
    document.querySelectorAll('.tela').forEach(tela => tela.classList.remove('ativa'));
    document.getElementById(id).classList.add('ativa');

    document.querySelectorAll('.sidebar li').forEach(item => item.classList.remove('active'));
    event.target.classList.add('active');
}

// Sistema de modo noturno
document.getElementById('darkMode').addEventListener('change', function () {
    document.body.style.backgroundColor = this.checked ? '#1b1b1b' : '#f4f6f8';
});

// Cadastro de salas (armazenamento local por enquanto)
document.getElementById('formCadastro').addEventListener('submit', (e) => {
    e.preventDefault();
    const nome = document.getElementById('nomeSala').value;
    const tipo = document.getElementById('tipoSala').value;
    const status = document.getElementById('statusSala').value;

    alert(`Sala cadastrada:\nNome: ${nome}\nTipo: ${tipo}\nStatus: ${status}`);

    e.target.reset();
});
