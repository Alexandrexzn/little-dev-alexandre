const express = require('express');
const path = require('path');
const dbConnection = require('./models/db'); // conexão MySQL
const app = express();
const PORT = 8080;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir arquivos estáticos da pasta src
app.use(express.static(path.join(__dirname, 'src')));

// ======= ROTAS =======

// Rota principal → abre o sistema
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'src', 'index.html'));
});

// Rota para listar salas
app.get('/api/salas', (req, res) => {
  const sql = 'SELECT * FROM salas';
  dbConnection.query(sql, (err, results) => {
    if (err) {
      console.error('Erro ao buscar salas:', err);
      return res.status(500).json({ success: false, message: 'Erro no servidor' });
    }
    res.json(results);
  });
});

// Rota para cadastrar nova sala
app.post('/api/salas', (req, res) => {
  const { nome, tipo, status } = req.body;

  if (!nome || !tipo || !status) {
    return res.status(400).json({ success: false, message: 'Campos obrigatórios ausentes.' });
  }

  const sql = 'INSERT INTO salas (nome, tipo, status) VALUES (?, ?, ?)';
  dbConnection.query(sql, [nome, tipo, status], (err, result) => {
    if (err) {
      console.error('Erro ao cadastrar sala:', err);
      return res.status(500).json({ success: false, message: 'Erro ao salvar no banco.' });
    }

    res.json({ success: true, message: 'Sala cadastrada com sucesso!' });
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
