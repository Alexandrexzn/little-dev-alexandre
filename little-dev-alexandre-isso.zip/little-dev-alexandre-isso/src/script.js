// =============================================================
// TROCA ENTRE TELAS
// =============================================================
function mostrarTela(id) {
    document.querySelectorAll('.tela').forEach(tela => tela.classList.remove('ativa'));
    document.getElementById(id).classList.add('ativa');

    document.querySelectorAll('.sidebar li').forEach(item => item.classList.remove('active'));
    const menuItem = document.querySelector(`.sidebar li[onclick="mostrarTela('${id}')"]`);
    if (menuItem) menuItem.classList.add('active');
}

// =============================================================
// MODO ESCURO
// =============================================================
document.getElementById('darkMode').addEventListener('change', function () {
    document.body.classList.toggle('dark-mode', this.checked);
});

// =============================================================
// CADASTRO COM ANDAR + VALIDAÇÃO
// =============================================================
document.getElementById('formCadastro').addEventListener('submit', function (e) {
    e.preventDefault();

    const nomeInput = document.getElementById('nomeSala');
    const tipoInput = document.getElementById('tipoSala');
    const andarSelect = document.getElementById('andarSala');
    const erroDiv = document.getElementById('erroCadastro');

    const nome = nomeInput.value.trim();
    const tipo = tipoInput.value.trim();
    const andar = andarSelect.value;

    // Remove erros anteriores
    nomeInput.classList.remove('input-erro');
    tipoInput.classList.remove('input-erro');
    andarSelect.classList.remove('input-erro');
    erroDiv.style.display = 'none';

    // === VALIDAÇÃO DO NOME: 2 a 10 dígitos ===
    const nomeValido = /^\d{2,10}$/.test(nome);
    if (!nomeValido) {
        nomeInput.classList.add('input-erro');
        erroDiv.textContent = 'Nome da sala: use de 2 a 10 números.';
        erroDiv.style.display = 'block';
        nomeInput.focus();
        return;
    }

    // === VALIDAÇÃO DO TIPO: mínimo 3 caracteres + pelo menos 1 letra ===
    const tipoTemLetra = /[A-Za-zÀ-ÿ]/.test(tipo);
    const tipoValido = /^[\wÀ-ÿ\s-]{3,}$/.test(tipo);
    if (!tipoValido || !tipoTemLetra) {
        tipoInput.classList.add('input-erro');
        erroDiv.textContent = 'Tipo da sala: mínimo 3 caracteres e pelo menos 1 letra.';
        erroDiv.style.display = 'block';
        tipoInput.focus();
        return;
    }

    // === VALIDAÇÃO DO ANDAR: obrigatório ===
    if (!andar) {
        andarSelect.classList.add('input-erro');
        erroDiv.textContent = 'Selecione o andar da sala.';
        erroDiv.style.display = 'block';
        andarSelect.focus();
        return;
    }

    // === EVITA DUPLICATAS ===
    const salaJaExiste = Array.from(document.querySelectorAll('#disponiveis .card h3'))
        .some(h3 => h3.textContent === nome);

    if (salaJaExiste) {
        nomeInput.classList.add('input-erro');
        erroDiv.textContent = 'Esta sala já está cadastrada.';
        erroDiv.style.display = 'block';
        nomeInput.focus();
        return;
    }

    // === CRIA O CARD COM ANDAR ===
    const novoCard = document.createElement('div');
    novoCard.classList.add('card');
    novoCard.innerHTML = `
        <h3>${nome}</h3>
        <p>${tipo} - ${andar} - Livre</p>
    `;

    // === ADICIONA NA TELA DE DISPONÍVEIS ===
    const container = document.querySelector('#disponiveis .cards-container');
    container.appendChild(novoCard);


    this.reset();
    andarSelect.selectedIndex = 0; 

    erroDiv.style.display = 'none';
    alert(`Sala ${nome} cadastrada com sucesso!`);
});

document.addEventListener('DOMContentLoaded', function () {
    mostrarTela('reservadas');
});