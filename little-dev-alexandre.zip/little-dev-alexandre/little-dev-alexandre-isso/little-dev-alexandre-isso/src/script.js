// ==================== VARIÁVEIS GLOBAIS ====================
let dataSelecionada = null;
let salaSelecionada = null;
let cardSelecionado = null;
let salaEditando = null;
let cardPeriodo = null;

// ==================== TROCA ENTRE TELAS ====================
function mostrarTela(id) {
    document.querySelectorAll('.tela').forEach(tela => tela.classList.remove('ativa'));
    document.getElementById(id).classList.add('ativa');
    document.querySelectorAll('.sidebar li').forEach(item => item.classList.remove('active'));
    const menuItem = document.querySelector(`.sidebar li[onclick="mostrarTela('${id}')"]`);
    if (menuItem) menuItem.classList.add('active');
}

// ==================== MODO ESCURO ====================
document.getElementById('darkMode').addEventListener('change', function () {
    const isDark = this.checked;
    document.body.classList.toggle('dark-mode', isDark);
    localStorage.setItem('modoEscuro', isDark);
});

document.addEventListener('DOMContentLoaded', () => {
    const modoEscuro = localStorage.getItem('modoEscuro') === 'true';
    document.getElementById('darkMode').checked = modoEscuro;
    if (modoEscuro) document.body.classList.add('dark-mode');
});

// ==================== CADASTRO DE SALA ====================
document.getElementById('formCadastro').addEventListener('submit', function (e) {
    e.preventDefault();
    const nome = document.getElementById('nomeSala').value.trim();
    const tipo = document.getElementById('tipoSala').value.trim();
    const andar = document.getElementById('andarSala').value;
    const erroDiv = document.getElementById('erroCadastro');

    const nomeValido = /^\d{2,10}$/.test(nome);
    const tipoValido = /^[\wÀ-ÿ\s-]{3,}$/.test(tipo) && /[A-Za-zÀ-ÿ]/.test(tipo);
    const salaExiste = Array.from(document.querySelectorAll('.sala-card')).some(card => card.dataset.sala === nome);

    if (!nomeValido || !tipoValido || !andar || salaExiste) {
        erroDiv.style.display = 'block';
        erroDiv.textContent = salaExiste ? 'Esta sala já está cadastrada.' : 'Preencha corretamente.';
        return;
    }

    const novoCard = document.createElement('div');
    novoCard.className = 'sala-card disponivel';
    novoCard.dataset.sala = nome;
    novoCard.innerHTML = `
        <div class="sala-header">
            <img src="./icons/computer.png" alt="Computador" class="sala-icone-img">
            <div class="sala-info">
                <p>Livre</p>
                <h3>${nome}</h3>
                <div class="acoes-sala">
                    <button class="btn-editar" title="Editar sala"><i class="fas fa-edit"></i></button>
                    <button class="btn-excluir" title="Excluir sala"><i class="fas fa-trash-alt"></i></button>
                </div>
            </div>
        </div>
        <div class="sala-detalhes">
            <button class="btn-reservar">RESERVAR</button>
        </div>
    `;

    document.querySelector('#disponiveis .sala-linha').appendChild(novoCard);
    this.reset();
    document.getElementById('andarSala').selectedIndex = 0;
    erroDiv.style.display = 'none';
    alert(`Sala ${nome} cadastrada com sucesso!`);
});

// ==================== MODAL DE RESERVA (NOME + HORÁRIO) ====================
const modalReserva = document.createElement('div');
modalReserva.className = 'modal-calendario';
modalReserva.innerHTML = `
    <div class="modal-conteudo">
        <div class="modal-header" style="background: #001f4d; color: white;">
            <h3>Completar Reserva</h3>
            <span class="fechar-reserva" style="cursor: pointer; font-size: 28px;">×</span>
        </div>
        <div style="padding: 24px;">
            <label style="display: block; margin: 15px 0 8px; font-weight: 600; color: #001f4d;">Nome do Professor</label>
            <input type="text" id="nome-professor" placeholder="Ex: Prof. Maria Silva" style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; font-size: 16px; margin-bottom: 16px;">

            <label style="display: block; margin: 8px 0; font-weight: 600; color: #001f4d;">Horário da Aula</label>
            <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                <input type="time" id="hora-inicio-reserva" value="07:30" style="padding: 10px; border: 1px solid #ddd; border-radius: 8px; font-size: 15px;">
                <span style="font-weight: 500;">à</span>
                <input type="time" id="hora-fim-reserva" value="11:30" style="padding: 10px; border: 1px solid #ddd; border-radius: 8px; font-size: 15px;">
            </div>
        </div>
        <div class="modal-footer" style="padding: 16px 24px; background: #f8f9fa; text-align: right; border-top: 1px solid #eee;">
            <button id="confirmar-reserva-final" class="btn-confirmar">Confirmar Reserva</button>
        </div>
    </div>
`;
document.body.appendChild(modalReserva);

// Fechar modal de reserva
modalReserva.querySelector('.fechar-reserva').addEventListener('click', () => {
    modalReserva.style.display = 'none';
});
window.addEventListener('click', (e) => {
    if (e.target === modalReserva) modalReserva.style.display = 'none';
});

// ==================== CALENDÁRIO ====================
const modalCalendario = document.getElementById('modalCalendario');
const fecharModal = document.querySelector('.fechar-modal');
const mesAnoTitulo = document.getElementById('mes-ano');
const gridCalendario = document.getElementById('calendario-grid');
const btnAnterior = document.getElementById('mes-anterior');
const btnProximo = document.getElementById('mes-proximo');
const btnConfirmarData = document.getElementById('confirmar-data');

let dataAtualCalendario = new Date();

function gerarCalendario(mes, ano) {
    gridCalendario.innerHTML = '';
    mesAnoTitulo.textContent = `${obterNomeMes(mes)} ${ano}`;

    const primeiroDia = new Date(ano, mes, 1).getDay();
    const diasNoMes = new Date(ano, mes + 1, 0).getDate();
    const hoje = new Date();
    const hojeFormatado = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate());

    for (let i = 0; i < primeiroDia; i++) {
        const vazio = document.createElement('div');
        vazio.className = 'dia vazio';
        gridCalendario.appendChild(vazio);
    }

    for (let dia = 1; dia <= diasNoMes; dia++) {
        const data = new Date(ano, mes, dia);
        const celula = document.createElement('div');
        celula.className = 'dia';
        celula.textContent = dia;

        if (data.getTime() === hojeFormatado.getTime()) {
            celula.classList.add('hoje');
        }

        celula.addEventListener('click', () => {
            document.querySelectorAll('.dia').forEach(d => d.classList.remove('selecionado'));
            celula.classList.add('selecionado');
            dataSelecionada = data;
        });

        gridCalendario.appendChild(celula);
    }
}

function mudarMes(delta) {
    const [mesNome, ano] = mesAnoTitulo.textContent.split(' ');
    let mes = obterNumeroMes(mesNome) + delta;
    let anoNum = parseInt(ano);

    if (mes > 11) { mes = 0; anoNum++; }
    if (mes < 0) { mes = 11; anoNum--; }

    dataAtualCalendario = new Date(anoNum, mes, 1);
    gerarCalendario(mes, anoNum);
}

// ==================== BOTÃO RESERVAR → ABRE CALENDÁRIO ====================
document.addEventListener('click', (e) => {
    if (e.target.closest('.btn-reservar')) {
        cardSelecionado = e.target.closest('.sala-card');
        salaSelecionada = cardSelecionado.querySelector('h3').textContent;
        modalCalendario.style.display = 'flex';
        dataSelecionada = null;
        document.querySelectorAll('.dia').forEach(d => d.classList.remove('selecionado'));
        gerarCalendario(new Date().getMonth(), new Date().getFullYear());
    }
});

// Navegação do calendário
btnAnterior.addEventListener('click', () => mudarMes(-1));
btnProximo.addEventListener('click', () => mudarMes(1));

// Fechar calendário
fecharModal.addEventListener('click', () => modalCalendario.style.display = 'none');
window.addEventListener('click', (e) => {
    if (e.target === modalCalendario) modalCalendario.style.display = 'none';
});

// Confirmar data → abre modal de reserva
btnConfirmarData.addEventListener('click', () => {
    if (!dataSelecionada) return alert('Selecione uma data!');
    modalCalendario.style.display = 'none';
    modalReserva.style.display = 'flex';
});

// ==================== CONFIRMAR RESERVA FINAL ====================
document.getElementById('confirmar-reserva-final').addEventListener('click', () => {
    const professorNome = document.getElementById('nome-professor').value.trim();
    const inicio = document.getElementById('hora-inicio-reserva').value;
    const fim = document.getElementById('hora-fim-reserva').value;

    if (!professorNome || !inicio || !fim) {
        return alert('Preencha o nome do professor e os horários.');
    }

    // Remove da lista de disponíveis
    cardSelecionado.remove();

    // Cria na tela de reservadas
    const novoCard = document.createElement('div');
    novoCard.className = 'sala-card';
    novoCard.dataset.sala = salaSelecionada;
    novoCard.innerHTML = `
        <div class="sala-header">
            <img src="./icons/education.png" alt="Professor" class="sala-icone-img">
            <div class="sala-info">
                <p>${professorNome}</p>
                <h3>${salaSelecionada}</h3>
                <div class="acoes-sala">
                    <button class="btn-editar"><i class="fas fa-edit"></i></button>
                    <button class="btn-excluir"><i class="fas fa-trash-alt"></i></button>
                </div>
            </div>
        </div>
        <div class="sala-detalhes">
            <span class="periodo">${dataSelecionada.toLocaleDateString('pt-BR')} • ${inicio} - ${fim}</span>
            <span class="capacidade">capacidade 30</span>
        </div>
    `;

    const linhaReservadas = document.querySelector('#reservadas .sala-linha');
    linhaReservadas.insertBefore(novoCard, linhaReservadas.firstChild);

    modalReserva.style.display = 'none';
    alert(`Reserva confirmada!\nSala: ${salaSelecionada}\nProfessor: ${professorNome}\nData: ${dataSelecionada.toLocaleDateString('pt-BR')}`);
});

// ==================== EDIÇÃO E EXCLUSÃO ====================
const modalEdicao = document.getElementById('modalEdicao');

document.addEventListener('click', (e) => {
    const btnEditar = e.target.closest('.btn-editar');
    const btnExcluir = e.target.closest('.btn-excluir');

    // === EXCLUIR SALA ===
    if (btnExcluir) {
        const card = btnExcluir.closest('.sala-card');
        const nomeSala = card.querySelector('h3').textContent;
        const responsavel = card.querySelector('p').textContent;
        
        if (confirm(`Tem certeza que deseja excluir a sala ${nomeSala} (${responsavel})?`)) {
            card.remove();
            alert(`Sala ${nomeSala} excluída com sucesso!`);
        }
        return;
    }

    // === EDITAR SALA ===
    if (btnEditar) {
        salaEditando = btnEditar.closest('.sala-card');
        const nome = salaEditando.querySelector('h3').textContent;
        const responsavel = salaEditando.querySelector('p').textContent;
        const capacidade = salaEditando.querySelector('.capacidade')?.textContent.replace('capacidade ', '') || '30';

        document.getElementById('editar-nome').value = nome;
        document.getElementById('editar-responsavel').value = responsavel;
        document.getElementById('editar-capacidade').value = capacidade;
        modalEdicao.style.display = 'flex';
    }
});

// Fechar modal de edição
document.querySelector('.fechar-edicao').addEventListener('click', () => {
    modalEdicao.style.display = 'none';
});

window.addEventListener('click', (e) => {
    if (e.target === modalEdicao) modalEdicao.style.display = 'none';
});

// Salvar alterações
document.querySelector('.btn-salvar-edicao').addEventListener('click', () => {
    const novoNome = document.getElementById('editar-nome').value.trim();
    const novoResp = document.getElementById('editar-responsavel').value.trim();
    const novaCap = document.getElementById('editar-capacidade').value;

    if (!novoNome || !novoResp || !novaCap) {
        return alert('Preencha todos os campos.');
    }
    
    if (!/^\d{2,10}$/.test(novoNome)) {
        return alert('O número da sala deve conter 2 a 10 dígitos.');
    }

    const salaJaExiste = Array.from(document.querySelectorAll('.sala-card'))
        .some(c => c.dataset.sala === novoNome && c !== salaEditando);

    if (salaJaExiste) {
        return alert('Esta sala já existe. Escolha outro número.');
    }

    salaEditando.dataset.sala = novoNome;
    salaEditando.querySelector('p').textContent = novoResp;
    salaEditando.querySelector('h3').textContent = novoNome;
    
    if (salaEditando.querySelector('.capacidade')) {
        salaEditando.querySelector('.capacidade').textContent = `capacidade ${novaCap}`;
    }

    modalEdicao.style.display = 'none';
    alert(`Sala ${novoNome} atualizada com sucesso!`);
});

// ==================== FUNÇÕES AUXILIARES ====================
function obterNomeMes(mes) {
    const meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
                   'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
    return meses[mes];
}

function obterNumeroMes(nome) {
    const meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
                   'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
    return meses.indexOf(nome);
}

// ==================== INICIALIZAÇÃO ====================
document.addEventListener('DOMContentLoaded', () => {
    mostrarTela('reservadas');
    gerarCalendario(new Date().getMonth(), new Date().getFullYear());
});